/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import controller.ControllerUsuario;
import java.util.Scanner;
import sw.ConversionSW;
import sw.ConversionSW_Service;
import view.LogIn;

/**
 *
 * @author Bryan
 */
public class TestWS {

    public static void main(String[] args) {
        ConversionSW_Service service = new ConversionSW_Service();
        
        ConversionSW cliente = service.getConversionSWPort();

        LogIn logIn = new LogIn();
        ControllerUsuario controllerUsuario = new ControllerUsuario(logIn,cliente);
        controllerUsuario.inicialControl();

        Scanner sc = new Scanner(System.in);
        boolean ban;
        do {
            ban = true;
            System.out.println("Ingrese su usuario");
            String user = sc.nextLine();
            System.out.println("Ingrese su contraseña");
            String password = sc.nextLine();
            System.out.println("=================================");
            String login=cliente.logIn(user, password);
            if (login.equalsIgnoreCase("OK")) {

                System.out.println(cliente.hello(user));
                System.out.println("=================================");
                System.out.println("Conversion :" + String.format("%.2f", cliente.euroAdolar(12)));
                System.out.println("Suma :" + String.format("%.2f", cliente.suma(122, 22)));
                System.out.println("Resta :" + String.format("%.2f", cliente.resta(123, 111)));
                System.out.println("Multiplicación :" + String.format("%.2f", cliente.multiplicacion(120, 6)));
                System.out.println("División :" + String.format("%.2f", cliente.division(125, 6)));
                System.out.println("Calcular hipotenusa :" + String.format("%.2f", cliente.tPitagoras(15, 9)));
                System.out.println("Calcular fuerza :" + String.format("%.2f", cliente.fuerza(14, 6)));
                System.out.println("Calcular aceleración :" + String.format("%.2f", cliente.aceleracion(0, 100, 3)));
                System.out.println("Calcular velocidad :" + String.format("%.2f", cliente.velocidad(50, 12)));

                ban = false;

            } else {
                System.out.println(login);
                System.out.println("=================================");

            }
        } while (ban);

    }
}
