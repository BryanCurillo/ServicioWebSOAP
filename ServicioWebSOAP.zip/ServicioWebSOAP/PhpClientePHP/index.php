<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //CREAR CLIENTE
        $cliente = new SoapClient('http://localhost:8080/DiccionarioSOAP/ConsultaWS?WSDL');
//METODOS
        //AGREGAR PALABRA
        $cliente->Agregar([
            "key" => "CPU",
            "signi" => "El procesador (CPU, Central Processing Unit) es el componente más importante dentro del PC. Es el cerebro de todo el funcionamiento del sistema, el encargado de dirigir todas las tareas que lleva a cabo el equipo y de ejecutar el código de los diferentes programas."
        ]);

        $consulta = $cliente->ConsultarPalabra([
                    "key" => "CPU"
                ])->return;
        echo "CPU:";
        echo $consulta;
        ?>

    </body>
</html>
