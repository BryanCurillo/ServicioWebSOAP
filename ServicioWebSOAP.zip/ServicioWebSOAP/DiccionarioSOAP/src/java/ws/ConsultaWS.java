/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package ws;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Bryan
 */
@WebService(serviceName = "ConsultaWS")
public class ConsultaWS {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    Map<String, String> diccionario = new HashMap<>();

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Diccionario")
    public void Diccionario() {
        diccionario.put("Esport", "Deportes electronicos, jugar videojuegos a nivel profecional");
        diccionario.put("Leon", "Felino de gran tamaño, considerado el rey de la sabana");
        diccionario.put("Motor", "Mecanismo que impulsa cualquier tipo de maquinaria");
        diccionario.put("IA", "Inteligencia artificial, algoritmos que se asemejan a una red neuronal");
        diccionario.put("Android", "Sistema operativo para smartphones basado en linux");
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "operation")
    public ArrayList<String> operation() {
        ArrayList<String> palabras = new ArrayList<String>();
        for (Map.Entry<String, String> dic : diccionario.entrySet()) {
            palabras.add(dic.getKey());
        }
        return palabras;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Agregar")
    public void Agregar(@WebParam(name = "key") String key, @WebParam(name = "signi") String signi) {
        diccionario.put(key, signi);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ConsultarPalabra")
    public String ConsultarPalabra(@WebParam(name = "key") String key) {
        Diccionario();
        String val = "";
        boolean ban = false;

        for (Map.Entry<String, String> dic : diccionario.entrySet()) {

            if (dic.getKey().equalsIgnoreCase(key)) {
                ban = true;
                val = dic.getValue();
                break;
            }
        }

        if (!ban) {
            val = "La palabra que buscas no existe en el diccionario";
        }
        return val;
    }
}
