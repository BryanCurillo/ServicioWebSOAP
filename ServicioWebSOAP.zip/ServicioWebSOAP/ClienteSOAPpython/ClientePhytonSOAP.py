from zeep import Client

# Crear Cliente
cliente = Client('http://localhost:8080/ProyectoSOAP/ConversionSW?WSDL')

# REGISTRO
registro = cliente.service.Registro("user1", "M5A", "M5A", "1200.5")


login = ""
if (registro == 'Registro exitoso'):
    # LOGIN
    login = cliente.service.LogIn("user1", "M5A")
    if (login == 'OK'):
        print("Credenciales correctas \n Bienvenido "+cliente.service.ObtenerDatos("user1", "M5A").user +
              "\n \t  Su saldo es de: $"+str(cliente.service.ObtenerDatos("user1", "M5A").saldo))
        print()

        print("Calcular la velocidad si un auto corre 120m en 4s: \n R=" +
              str(cliente.service.Velocidad(120, 4)))
    else:
        print(login)

else:
    print(registro)
