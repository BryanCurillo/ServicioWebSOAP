/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.DefaultListModel;
import view.viewDiccionario;
import ws.ConsultaWS;
import ws.ConsultaWS_Service;

/**
 *
 * @author Bryan
 */
public class controllerDiccionario {

    ConsultaWS cli;
    viewDiccionario view;

    public controllerDiccionario(ConsultaWS cli, viewDiccionario view) {
        this.cli = cli;
        this.view = view;
        this.view.setLocationRelativeTo(null);
        this.view.setVisible(true);
        this.view.setTitle("Diccionario");
        cargarpalabras();
    }

    public void iniciarcontrol() {
        view.getBtnBuscar().addActionListener(l -> consultar());
        view.getBtnAgregar().addActionListener(l->agregar());
        view.getBtnLimpiar().addActionListener(l->limpiar());
    }

    public void consultar() {
        String key = view.getTxtpalabra().getText();

        view.getTxtPsignificado().setText(cli.consultarPalabra(key));
    }

    public void cargarpalabras() {
        ArrayList<String> palabras = new ArrayList<String>();
        palabras=(ArrayList<String>) cli.operation();
        DefaultListModel<String> model = new DefaultListModel<>();
        Collections.sort(palabras);
        System.out.println("hola- "+palabras.size());
        for (String p : palabras) {
            model.addElement(p);
            view.getListPalabras().setModel(model);
        }

    }
    
    public void agregar(){
        String key=view.getTxtSetPalabra().getText(),
                signi=view.getTxtSetSigni().getText();
        cli.agregar(key, signi);
        cargarpalabras();
        limpiar();
    }

    public void limpiar(){
        view.getTxtSetPalabra().setText("");
        view.getTxtPsignificado().setText("");
        view.getTxtSetSigni().setText("");
        view.getTxtpalabra().setText("");
    }
}
